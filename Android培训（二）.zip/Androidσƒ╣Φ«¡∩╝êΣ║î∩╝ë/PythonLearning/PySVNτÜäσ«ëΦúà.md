##MACOSX 下 PYSVN的安装

#####From JiaYing.Cheng

---
---

本来以为PYSVN 跟linux的安装一样，于是去官网下载 ，然后一直出错，后来GOOGLE发现 PYSVN 居然有DMG包。好吧。你赢了。。

http://pysvn.tigris.org/servlets/ProjectDocumentList?folderID=2860 这里是下载地址。PYTHON各种版本的DMG都在，很全。
